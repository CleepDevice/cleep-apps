#!/bin/sh

python3 -m pip uninstall --yes "cleepcli"; /bin/true

