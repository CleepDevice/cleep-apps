#!/bin/sh

python3 -m pip uninstall --yes "RPi.GPIO"

